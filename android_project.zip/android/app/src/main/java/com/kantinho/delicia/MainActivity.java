package com.kantinho.delicia;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
